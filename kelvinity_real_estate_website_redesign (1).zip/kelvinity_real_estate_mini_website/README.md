# Realtor Kelvinity Real Estate Website

A responsive static website for land and properties in Abuja. All website photos used by the page are stored locally in `assets/` so the property images do not depend on external image-host URLs.

## Publish on GitHub Pages
1. Download and extract this ZIP.
2. Upload `index.html`, `README.md`, and the entire `assets` folder into the root of your GitHub repository.
3. Commit the changes.
4. In repository Settings → Pages, select the main branch and root folder if Pages is not already enabled.

Google Form: https://docs.google.com/forms/d/e/1FAIpQLScATENUvS0UNcgPzABVqeRA9OjEpmHdVHu0kBPhGKmtWFF-wQ/viewform
WhatsApp: https://wa.me/2348135314919

Property photos are illustrative. Confirm availability, prices, title and documentation directly before making payment.
